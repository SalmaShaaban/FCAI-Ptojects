#include <iostream>

#include "stdio.h"
#include "stdlib.h"
#include "limits.h"
using namespace std;


static int flag ;
class  node
{
    int key;
     node *left;
     node *right;
    int left_child;
    int right_child;
    int Height;

public:
int max (int a, int b)
{
    return a > b ? a : b;
}

int height (node *root)
{
    return (root == NULL) ? 0 : root -> Height;
}

node *new_node (int key, int left_child, int right_child)
{
    node *tmp_node = (node *) malloc( sizeof(node) );
    tmp_node -> key = key;
    tmp_node -> left = NULL;
    tmp_node -> right = NULL;
    tmp_node -> Height = 1;
    tmp_node -> left_child = left_child;
    tmp_node -> right_child = right_child;
    return tmp_node;
}

node *right_rotate (node *y)
{
    node *x = y -> left;
    node *T2 = x -> right;

    x -> right = y;
    y -> left = T2;

    y -> Height = max( height(y -> left), height(y -> right) ) + 1;
    x -> Height = max( height(x -> left), height(x -> right) ) + 1;

    if (T2 != NULL)
        y -> left_child = T2 -> left_child + T2 -> right_child + 1;
    else
     y -> left_child = 0;
    x -> right_child = y -> left_child + y -> right_child + 1;

    return x;
}

node *left_rotate (node *x)
{
    node *y = x -> right;
    node *T2 = y -> left;

    y -> left = x;
    x -> right = T2;

    x -> Height = max( height(x -> left), height(x -> right) ) + 1;
    y -> Height = max( height(y -> left), height(y -> right) ) + 1;

    if (T2 != NULL) x -> right_child = T2 -> left_child + T2 -> right_child + 1;
    else x -> right_child = 0;
    y -> left_child = x -> left_child + x -> right_child + 1;

    return y;
}

int get_balance_factor (node *root)
{
    if (root == NULL) return 0;
    else return height(root -> left) - height(root -> right);
}

node* insert(node *root, int key)
{
    if (root == NULL)
        return new_node(key, 0, 0);
    if (key < root -> key)
    {
        root -> left = insert(root -> left, key);
        root -> left_child++;
    }
    else if (key > root -> key)
    {
        root -> right = insert(root -> right, key);
        root -> right_child++;
    }
    else return root;

    root -> Height = max( height(root -> left), height(root -> right) ) + 1;

    int balance = get_balance_factor(root);

    if ( (balance > 1) && (key < root -> left -> key) ) return right_rotate(root);

    if ( (balance < -1) && (key > root -> right -> key) ) return left_rotate(root);

    if ( (balance > 1) && (key > root -> left -> key) )
    {
        root -> left = left_rotate(root -> left);
        return right_rotate(root);
    }

    if ( (balance < -1) && (key < root -> right -> key) )
    {
        root -> right = right_rotate(root -> right);
        return left_rotate(root);
    }

    return root;
}


int find_by_key (node *root, int key)
{
    if (root != NULL)
    {
        if (key > root -> key)
            return root -> left_child + 1 + find_by_key(root -> right, key);
        else if (key < root -> key)
            return find_by_key(root -> left, key);
        else
            return root -> left_child;
    }
    else
    {

        flag = 1;
        return -1;
    };
}


};

int main ()
{

    int n;
    cin >> n;
    int arr[n];
    node *root = NULL;
    int s =0;
    for (int i = 0; i < n; i++)
    {
        short int op;
        int num;
        cin >> op >>num;
        if (op == 1)
        {

            root = root->insert(root, num);
        }
        if (op == 2)
        {

            flag = 0;
            int rank = root->find_by_key(root, num) + 1;
            if (flag)
               {
               arr[s]=-1;
                s++;
               }
            else
                {
                    arr[s]= rank ;
                    s++;
        }
        }

    }
     for (int i=0;i<s;i++)
     {
         cout<<arr[i]<<" ";
     }


    return 0;
}
