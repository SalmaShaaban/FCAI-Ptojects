#include <iostream>
#include <cstring>
#include <sstream>
using namespace std;

int countInv(int array[], int n)
{
    int counter = 0;
    for (int i = 0; i < n - 1; i++)
        for (int j = i + 1; j < n; j++){
             if (array[i] > array[j])
                counter++;
        }
    return counter;
}
int main()
{
  //  int arr1[]={5,2,14,6,1,0};
    //int n = sizeof(arr1) / sizeof(arr1[0]);
    //int arrayCounter=0;
    //for (int k=0 ; k<n ; k++)
    //{
      //  arrayCounter++;
    //}
    //cout <<"Number Of Array Elements Is : "<< arrayCounter<< endl;

    //cout << "Number Of Inversions Is : "
         //<< countInv(arr1, n)<<endl;

         /////////////////////////////////////
cout << "Enter Your Array Elements :" <<endl ;
int arrSize=0;
int *arr1= new int();
char inputArr[50];
cin.getline(inputArr,50);
char *p;
p = strtok(inputArr," ");
   while (p != NULL)
    {
        stringstream geek(p);
        geek>>arr1[arrSize];
        p = strtok (NULL," ");
        arrSize++;

    }
cout <<"Number Of Array Elements Is : "<< arrSize<< endl;

    cout << "Number Of Inversions Is : "  << countInv(arr1, arrSize)<<endl;

    return 0;
}
