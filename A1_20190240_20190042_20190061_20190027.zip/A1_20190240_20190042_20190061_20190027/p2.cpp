///problem 2
#include <iostream>
#include <algorithm>//
using namespace std;

 // int result=0 ;
 long long mw,mz;

     void swap(int arr[], int i, int j)
        {
            int temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }


    int part(int arr[], int low, int heigh)
        {
            //heigh
            int pivo = arr[heigh];
            // insert numbers in array
            int i = low - 1;

            for (int j = low; j <= heigh - 1; j++)
                {
                    if (arr[j] < pivo)
                        {
                            i++;
                            swap(arr, i, j);
                        }
                }
            swap(arr, i + 1, heigh);
            return (i + 1);
        }

    int qsort(int arr[], int low, int heigh, int kth)
         {

            if(low == heigh)
                {
                return arr[low];
                }
            else
             {

                int pos = part(arr, low, heigh);
                int rank = pos - low + 1;
                if (kth == rank)
                    {
                        return arr[pos];
                    }
                if (kth < rank)
                    {
                       return qsort(arr, low, pos - 1, kth);
                    }
                else
                    {
                        return qsort(arr, pos + 1, heigh, kth-rank);

                    }

            }

        //return result;

    }
     long long random()
        {

        mz=36969*(mz&65535)+(mz>>16);
        mw=18000*(mw&65535)+(mw>>16);
        long long res=(mz<<16)+mw;
        return res%1000000000;
        }



int main()
{

        int n=0;
        int* arr;
        int kth;


        cout<<"inter the input"<<endl;
        cin>>n>>kth>>mw>>mz;
          arr=new int[n];

///arr=new int[n];

        for (int i = 0; i < n; i++)
            {
                arr[i]=(int)random();
            }
///sizeof(arr)/sizeof(arr[0])-1   --> get the this of bits not the length

        int result=qsort(arr,0,n-1,kth);
        cout<<result<<endl;

cout<<"it is Done"<<endl;

}
