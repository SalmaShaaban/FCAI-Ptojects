#include <iostream>
#include <cstring>
#include <sstream>
using namespace std;
int numOfSwaping (int arr[], int n){
int key,j,swap=0;
for(int i=1;i<n;i++){
    key=arr[i];
    j=i-1;
    while(j>=0&& arr[j]>key){
        arr[j+1]=arr[j];
        j--;
        arr[j+1]=key;
        swap=swap+1;
    }
}
return swap;
}

int main()
{
int size=0;
int *a= new int();
char input[100];
cin.getline(input,100);
char *ptr;
ptr = strtok(input," ");
   while (ptr != NULL)
    {
        stringstream geek(ptr);
        geek>>a[size];
        ptr = strtok (NULL," ");
        size++;

    }
int result= numOfSwaping(a,size);
cout<<result;
    return 0;
}
