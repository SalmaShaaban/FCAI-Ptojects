#include<iostream>
#include<unordered_map>
using namespace std;

int main(){

	int arr1[] = {1,2,3,1,2,1};
    int n = sizeof(arr1) / sizeof(int);

	unordered_map <int,int> Map;

	for(int i=0;i<n;i++) Map[arr1[i]]++;

	for(int i=0;i<n;i++){
		if(Map.find(arr1[i]) != Map.end()){
			int x = Map[arr1[i]];
			while(x--)
                cout<<arr1[i]<<" ";
			Map.erase(arr1[i]);
		}
	}
	return 0;
}
