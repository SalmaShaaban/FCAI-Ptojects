#include<iostream>
#include<cstring>

using namespace std;
const int maxn=100000000;

struct Node
{
public:
    int row,col;
};
Node node[15];
int num;
int m1[15][15],m2[15][15];

void printMatrix(int x,int y){

    if(x==y)
        cout<<"A"<<x+1;
    else{
        cout<<"(";
        printMatrix(x, m2[x][y]);
        cout<<" x ";
        printMatrix(m2[x][y]+1, y);
        cout<<")";
    }
}

int main()
{
    int pos=0, res;
    cout<<"Enter number of rows"<<endl;
    while(cin>>num&&num){
        cout<<"Enter matrix:row, column "<<endl;
        for(int i=0;i<num;i++){
            cin>>node[i].row>>node[i].col;
        }
        memset(m1,0,sizeof(m1));
        memset(m2,0,sizeof(m2));
        for(int l=1;l<num;l++){
            for(int i=0;i<num-l;i++){
                int j=l+i;
                m1[i][j]=maxn;
                for(int k=i;k<j;k++){
                    res=m1[i][k]+m1[k+1][j]+node[i].row*node[k].col*node[j].col;
                    if(res<m1[i][j]){
                        m1[i][j]=res;
                        m2[i][j]=k;
                    }
                }
            }
        }
        cout<<"Result of Case "<<++pos<<"= ";
        printMatrix(0, num-1);
        //cout<<endl;
        break;
    }
        return 0;
    }
