#include <iostream>
#include <float.h>
#include <math.h>
using namespace std;

struct Point
{
	int x , y;
};

float calcDist(Point firstP, Point secondP)
{
	return sqrt( (firstP.x - secondP.x)*(firstP.x - secondP.x) + (firstP.y -secondP.y)*(firstP.y - secondP.y));
}

float bruteForce(Point P[], int pSize)
{
	float minDis = FLT_MAX;// when include <float.h>
	for (int i = 0; i < pSize; ++i)
		for (int j = i+1; j < pSize; ++j)
			if (calcDist(P[i], P[j]) < minDis)
				minDis = calcDist(P[i], P[j]);
	return minDis;
}
int compareByX(const void* i, const void* j)
{
	Point *point1 = (Point *)i, *point2 = (Point *)j;
    if (point1->x != point2->x)
        return point1->x - point2->x;
    else
    return point1->y - point2->y;
}
int compareByY(const void* i, const void* j)
{
	Point *point1 = (Point *)i, *point2 = (Point *)j;
	if (point1->y != point2->y)
        return point1->y - point2->y;
    else
    return point1->x - point2->x;
}

float stripClosest(Point strip[], int stripSize, float dist)
{
	float minDist = dist;
	for (int i = 0; i < stripSize; ++i)
		for (int j = i+1; j < stripSize && (strip[j].y - strip[i].y) < minDist; ++j)
			if (calcDist(strip[i],strip[j]) < minDist)
				minDist = calcDist(strip[i], strip[j]);

	return minDist;
}

float closestPoints(Point PByx[], Point PByy[], int Size)
{
	if (Size <= 3)
		return bruteForce(PByx, Size);

	int middel = Size/2;
	Point midPoint = PByx[middel];
	Point Pyl[middel];
	Point Pyr[Size-middel];
	int li = 0, ri = 0;
	for (int i = 0; i < Size; i++)
	{
	if ((PByy[i].x < midPoint.x || (PByy[i].x == midPoint.x && PByy[i].y < midPoint.y)) && li<middel)
		Pyl[li++] = PByy[i];
	else
		Pyr[ri++] = PByy[i];
	}
	float dl = closestPoints(PByx, Pyl, middel);
	float dr = closestPoints(PByx + middel, Pyr, Size-middel);
	float dist = min(dl, dr);
	Point strip[Size];
	int counter = 0;
	for (int i = 0; i < Size; i++)
		if (abs(PByy[i].x - midPoint.x) < dist)
			strip[counter] = PByy[i], counter++;
	return stripClosest(strip, counter, dist);
}

float findSmallest(Point P[], int n)
{
	Point Px[n];
	Point Py[n];
	for (int i = 0; i < n; i++)
	{
		Px[i] = P[i];
		Py[i] = P[i];
	}
	qsort(Px, n, sizeof(Point), compareByX);
	qsort(Py, n, sizeof(Point), compareByY);
	return closestPoints(Px, Py, n);
}

int main()
{
	Point arrOfPoints[] = {{2, 7},{12, 6},{4, 15},{9, 1},{1, 8},{3, 4}};//{2, 7},{1, 8} ,are the closest here ..
	int arrSize = sizeof(arrOfPoints)/sizeof(arrOfPoints[0]);
	cout << " So , Smallest Distance Between Two Points Is : " << findSmallest(arrOfPoints, arrSize)<<endl;
	return 0;
}
