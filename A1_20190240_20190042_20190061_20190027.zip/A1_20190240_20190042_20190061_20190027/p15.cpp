#include <iostream>
#include <cstring>
#include <sstream>
#include<unordered_set>
using namespace std;
int findtMinimumIndexOfRepeatingElement(int arr[],int length){
unordered_set<int> s;
int minIndex=-1;


    for (int i = length-1; i >=0; i--) {
      if (s.find(arr[i])!= s.end()){
           minIndex=i;
          }
       else {
        s.insert(arr[i]);
      }
    }
    if(minIndex==-1){
        return-1;
    }
    else return minIndex;



}

int main()
{
int size=0;
int *a= new int();
char input[100];
cout<<"Enter the Numbers separated with space: ";
cin.getline(input,100);
char *ptr;
ptr = strtok(input," ");
   while (ptr != NULL)
    {
        stringstream geek(ptr);
        geek>>a[size];
        ptr = strtok (NULL," ");
        size++;
    }
    int result = findtMinimumIndexOfRepeatingElement(a,size);
    if(result==-1){
        cout<<"Invalid Input"<<endl;
    }
    else{
        cout<<result;
    }
    return 0;
}
