//problem#4
#include <bits/stdc++.h>
#include <iostream>
using namespace std;


// multiSet have a several integer as example  will be 200
int a[200];
// multiSet sort in ordered way if we use it
//compare function  left and right  like the tree

int comp(int l, int r)
{
    if (l >= r)
        return 0;

    int x;
    x = min_element(a + l, a + r) - a;
    int mn;
    mn = a[x];

    // i=l , i <r so, mean that l <r so
    for (int i = l; i <= r; i++)

    {
        //a[i]=a[i]-mn;

        a[i] -= mn;// remove the occurrence
    }
//return the comparable
    return min(r - l, comp(l, x) + comp(x + 1, r) + mn);
}
main()
{
    int s;
    cout<<"enter the number of the samples you want to check on it"<<endl;
    cin >> s;
    cout<<"enter the samples using space after every sample"<<endl;
    for (int i = 0; i < s; i++)
    {
        cin >> a[i];
    }
    cout << comp(0, s);
}
