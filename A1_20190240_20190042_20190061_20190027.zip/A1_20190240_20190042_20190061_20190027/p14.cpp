#include <iostream>
#include <cstring>
#include <sstream>
#include<set>
using namespace std;
void findPairs(int arr[],int length, int target){
set<int> s;
int flag=0;
 //  pair<int,int> *pairs = new   pair<int,int>();
    for (int i = 0; i < length; i++) {
      if (s.find(target-arr[i])!= s.end()){
          cout<<"("<<target-arr[i]<<","<<arr[i]<<") ";
          flag=1;
          }
       else {
        s.insert(arr[i]);
      }
    }
    if(flag==0) cout<<"Pair not found"<<endl;


}
int main()
{
int size=0,targetSum;
int *a= new int();
char input[100];
cout<<"Enter the Numbers separated with space: ";
cin.getline(input,100);
cout<<"Target: ";
cin>>targetSum;
char *ptr;
ptr = strtok(input," ");
   while (ptr != NULL)
    {
        stringstream geek(ptr);
        geek>>a[size];
        ptr = strtok (NULL," ");
        size++;
    }
    findPairs(a,size,targetSum);

    return 0;
}
