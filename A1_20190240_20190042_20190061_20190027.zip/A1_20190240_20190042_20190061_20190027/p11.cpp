#include <iostream>
#include <cstring>
#include <sstream>
using namespace std;

int maxOfThem(int x , int y){
    if (x>=y){
      return x ;
    }
    else if (x<=y){
      return y ;
    }
    else {
      return -1;
    }
}


// #########################
int maxSubArrSum(int arr[],int n)
{
   // int arrSize = sizeof(arr) / sizeof(arr[0]);
    int withPrv=arr[0];
    int withOutPrv=0;
    int nWithOutPrv;

    for(int k=1 ; k<n ; k++)
    {
        nWithOutPrv = maxOfThem(withPrv,withOutPrv);
        withPrv=withOutPrv+arr[k];
        withOutPrv=nWithOutPrv;
    }
    return maxOfThem(withPrv,withOutPrv);

 }
   // #########################

int main()
{

  cout << "Enter Your Array Elements :" <<endl ;
  int arrSize=0;
  int *arr1= new int();
  char inputArr[50];
  cin.getline(inputArr,50);
  char *p;
  p = strtok(inputArr," ");
   while (p != NULL)
    {
        stringstream geek(p);
        geek>>arr1[arrSize];
        p = strtok (NULL," ");
        arrSize++;
    }
        cout<< "Sum Is : " <<maxSubArrSum(arr1 , arrSize);

        return 0;
}
