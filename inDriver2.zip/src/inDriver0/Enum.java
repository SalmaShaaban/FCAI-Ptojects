package inDriver0;
enum Role {
	  Passenger,
	  Driver
	  }
