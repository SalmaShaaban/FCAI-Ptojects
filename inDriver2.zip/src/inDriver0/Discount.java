package inDriver0;

interface Discount {
        double discount();
}

