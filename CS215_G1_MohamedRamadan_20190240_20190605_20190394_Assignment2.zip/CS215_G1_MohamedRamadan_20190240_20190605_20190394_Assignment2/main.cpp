#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <utility>
using namespace std;

static int ref=1;
struct Record{
    int key;
    int value;
};
class sequenceSet{
    Record bigHeader;
    Record* recordHeader;
    Record* record;
    int blockSize;
    int numOfBlocks;
    vector<int> byteoffset;
public:
    bool CreateRecordFile(fstream &cIndexFile, int m, int n) {
        if (!cIndexFile.good()) {
            return false;
        }
        numOfBlocks = m;
        blockSize = n;
        record = new Record[blockSize + 1];
        recordHeader = new Record[numOfBlocks];
        for (int i = 0; i < numOfBlocks; i++) {
            if (i == 0)
                cIndexFile << "       #";
            else
                cIndexFile << "  #";
          //  cout << "  #";
            byteoffset.push_back(cIndexFile.tellg());
            cIndexFile.seekp(byteoffset[i], ios::beg);
            if (i == numOfBlocks - 1) {
                recordHeader[i].key = -1;
                recordHeader[i].value = -1;
                record[0] = recordHeader[i];
            } else {
                ref++;
                recordHeader[i].key = ref;
                recordHeader[i].value = -1;
                record[0] = recordHeader[i];
            }
             if (recordHeader[i].key>=0 && recordHeader[i].key<10)
                 cIndexFile<<"0";
            cIndexFile << recordHeader[i].key << "/";
            if (recordHeader[i].value>=0 && recordHeader[i].value<10)
                cIndexFile<<"0";
            cIndexFile << recordHeader[i].value << "|";
           // cout << recordHeader[i].key << "/"
             //    << recordHeader[i].value << "|";
            for (int j = 0; j < blockSize; j++) {
                record[j].key = -1;
                record[j].value = -1;
                cIndexFile << "  " << "/"
                           << "  " << "|";
            //    cout << "  " << "/"
              //       << "  " << "|";

            }
        }
        updateHeader(cIndexFile);
    }
    void updateHeader(fstream& cIndexFile){
        bool found = false;
        for (int i =0;i<numOfBlocks;i++) {
            cIndexFile.seekp(0,ios::beg);
            if (recordHeader[i].value!= -1) {
                bigHeader.key=i;
                if (bigHeader.key>=0 && bigHeader.key<10)
                    cIndexFile<<"0";
                cIndexFile << bigHeader.key;
                found = true;
                break;
            }
        }
        if (!found){
            bigHeader.key=-1;
            if (bigHeader.key>=0 && bigHeader.key<10)
                cIndexFile<<"0";
            cIndexFile << bigHeader.key;
        }

        cIndexFile<<"/";
        found = false;
        for (int i =0;i<=numOfBlocks;i++) {
            //int keyI=readInterger(i,cIndexFile);
            if (recordHeader[i].value == -1) {
                bigHeader.value=i+1;
                if (bigHeader.value>=0 && bigHeader.value<10)
                    cIndexFile<<"0";
                cIndexFile << bigHeader.value;
                found = true;
                break;
            }
        }
        if (!found){
            bigHeader.value = -1;
            if (bigHeader.value>=0 && bigHeader.value<10)
                cIndexFile<<"0";
            cIndexFile<<bigHeader.value;
        }
    }
    int InsertVal(fstream& cIndexFile, int iToken, int iKeyy) {
        bool fullBlock = false;
        bool found = false;
        int index = 0, x = 1;
        string iKey=to_string(iKeyy);
        string iValue=to_string(iToken);
//  cIndexFile.seekp(byteoffset[i],ios::beg);
        for (int i = 0; i < numOfBlocks; i++) {
            for (int j = 0; j <= blockSize ; j++) {
                string z="";

                if (readKey(i,j,cIndexFile)==iKey) {
                    found = true;
                    index = i + 1;
                    break;
                }

            }
        }
        if (found){
            cout<<endl<<iKey<<" is found in block "<<index<<endl;
            return 1;
        }
        string a="";

        char c;
        cIndexFile.seekp(0,ios::beg);
        string x1 =readInterger(-1,cIndexFile);
        if (x1=="-1") {
            cIndexFile.seekp(byteoffset[0], ios::beg);
            string q1 = readKey(0,0,cIndexFile);
            string q2 = readValue(0,0,cIndexFile);
            if (readValue(0,0,cIndexFile)=="-1") {//error
                setKey(0,1,iKey,cIndexFile);
                  setValue(0,1,iValue,cIndexFile);
                string x2= readKey(0,1,cIndexFile);
                setValue(0,0,x2,cIndexFile);
                string x4= readKey(-1,0,cIndexFile);
                int x5 =stoi(x4);
                x5+=2;
                x4= to_string(x5);
                setKey(-1,0, x4,cIndexFile);
                string x6= readValue(-1,0,cIndexFile);
                int x7 =stoi(x6);
                x7++;
                x6= to_string(x7);
                setValue(-1,0, x6,cIndexFile);
            }
        }
        else{
            for (int i =0;i<numOfBlocks;i++) {
                if (fullBlock){
                    x--;
                    string x8= readValue(-1,0,cIndexFile);
                    int x9 =stoi(x8);
                    x9++;
                    x8= to_string(x9);
                    setValue(-1,0, x8,cIndexFile);
                    fullBlock= false;
                }
                string x10=readKey(-1,0,cIndexFile);
                int x11= stoi(x10);
                if (x11 == i+x) {  //hereee
                    cIndexFile.seekp(byteoffset[i], ios::beg);
                    for (int j = 0; j <= blockSize; j++) {
                            string x15 =readKey(i, j, cIndexFile);
                        if ( x15== "") {
                            found = true;
                            setKey(i, j, iKey, cIndexFile);
                            setValue(i, j, iValue, cIndexFile);
                            string x12 = readValue(i, 0, cIndexFile);
                            string x13 = readKey(i, j, cIndexFile);
                            if (x12 < x13)//  recordHeader[i].second < record[j].first)
                                setValue(i, 0, readKey(i, j, cIndexFile), cIndexFile);
                            //   recordHeader[i].second = record[j].first;
                      //      sortBlock(cIndexFile);


                            return i + 1;
                        }
                        if (j == blockSize - 1) {
                            fullBlock = true;
                        }

                        if (!found)
                            continue;


                    }
                }
            }

        }


    }
    /*void print(fstream& cIndexFile){
        for (int i =0;numOfBlocks;i++){
            cIndexFile.seekp(byteoffset[i],ios::beg);
            char x='0';
            string s="";
            cIndexFile>>x;
            while(x!='#'){
                s+=x;
                cIndexFile>>x;
            }
            cout<<s;
        cout<<endl;
        }
    }*/
    string readInterger(int c,fstream& file){    //number of block
        if (c==-1)
            file.seekp(0,ios::beg);
        else
            file.seekp(byteoffset[c],ios::beg);
        string z="";
        char x;
        file>>x;
        while(!file.eof() ){
            if (x=='/' ||x=='|')
                break;
            z+=x;
            file>>x;
        }
        return z;
    }
    string readKey(int blockNumber,int i,fstream& file){
        if (blockNumber==-1)
            file.seekp(0,ios::beg);
        else
            file.seekp(byteoffset[blockNumber]+i*6,ios::beg);
        string z="";
        char x;
        file>>x;
        while(!file.eof() ){
            if (x=='/' )
                break;
            z+=x;
            file>>x;
        }
        return z;
    }
    string readValue(int blockNumber,int i,fstream& file){
        if (blockNumber==-1)
            file.seekp(3,ios::beg);
        else
            file.seekp(byteoffset[blockNumber]+3+(i*6),ios::beg);
        string z="";
        char x;
        file>>x;
        while(!file.eof() ){
            if (x=='|' ){
                break;
            }
            if (blockNumber==-1){
                if (x==' ' ){
                    break;
                }
            }
            z+=x;
            file>>x;
        }
        return z;
    }
    void setKey(int blockNumber,int i,string keyy,fstream& file){
        if (blockNumber==-1)
            file.seekp(0,ios::beg);
        else
            file.seekp(byteoffset[blockNumber]+i*6,ios::beg);
        if (keyy.length() == 1)
                file << "0";
        file<<keyy;
    }
    void setValue(int blockNumber,int i,string valuee,fstream& file){
        if (blockNumber==-1)
            file.seekp(3,ios::beg);
        else
            file.seekp(byteoffset[blockNumber]+3+(i*6),ios::beg);
        if (valuee.length()==1)
            file<<"0";

        file<<valuee;
    }
    void sortBlock(fstream& file){
        vector<pair<string ,string>> record;
        for (int i=0;i<numOfBlocks;i++){
            for (int j=1;j<blockSize;j++){
                string x1 = readKey(i,j,file);
                string x2 = readValue(i,j,file);
                record.push_back(make_pair(x1,x2));
            }
        }
        int j;
        for (int z =1;z<blockSize;z++){
            j=z;
            if (record[j].first=="-1" )
                continue;
            while (j>0 &&record[j-1].first>record[j].first){
                swap(record[j-1],record[j]);
                j-=1;
            }
        }
        for (int i=0;i<numOfBlocks*blockSize;i++){
                 setKey(i,j,record[i].first,file);
                setValue(i,j,record[i].second,file);
            }
        }
   int searchByKey(int ik,fstream& cIndexFile){
        string h,r=NULL;
    for(int i=0;i<numOfBlocks;i++){
            int index= byteoffset[i];
            cIndexFile.seekg(index+6,ios::beg);
           getline(cIndexFile,h,'/');
           //h=cIndexFile.get();
            stringstream geek(h);
            int x=0;
            geek>>x;
            if(x>=ik){
             while(r!=h){
            index=index+5;
            cIndexFile.seekg(index,ios::cur);
            getline(cIndexFile,r,'/');
            h=cIndexFile.get();
        }

    }        }
    if(r==h) return (cIndexFile.tellg());
    else return -1;
}
void DeleteKey (fstream& cIndexFile, int iToken) // iToken = iKey
{
     for(int i = 0; i < numOfBlocks; i++)
     {
        for(int j = 0; j <= blockSize; j++)
        {
           if(record[j].key == iToken)
           {
              setKey(i,j,"  ", cIndexFile);
              setValue(i,j,"  ", cIndexFile);
           }

           /*
           if (iToken == record[0].value)
           {
            // record[0].value = iToken;
           }*/
        }
     }
}
int GetKey(fstream &cIndexFile, int iBlock, int iRecord){
int index = byteoffset[iBlock-1];
cIndexFile.seekg(index+6,ios::beg);
index= index+(6*iRecord);
cIndexFile.seekg(index,ios::cur);
string h,r=NULL;
getline(cIndexFile,h,'/');
if(h=="-1"){
    return -1;
}
else{
      stringstream geek(h);
            int x=0;
            geek>>x;
            return x;
}
}
int GetVal(fstream &cIndexFile, int iBlock, int iRecord){
int index = byteoffset[iBlock-1];
cIndexFile.seekg(index+9,ios::beg);
index= index+(6*iRecord);
cIndexFile.seekg(index,ios::cur);
string h,r=NULL;
getline(cIndexFile,h,'/');
if(h=="-1"){
    return -1;
}
else{
      stringstream geek(h);
            int x=0;
            geek>>x;
            return x;
}
}
int GetBlockIndex (fstream &cIndexFile, int iToken){
int index= searchByKey(iToken,cIndexFile);
if(index==-1) return -1;
for (int i=0;i<byteoffset.size();i++){
if(index>byteoffset[i]&&index<byteoffset[i]){
    return i;
}
}

}
int GetRecordIndex (fstream &cIndexFile, int iToken){
            string h,r=NULL;
             int num=0;
for(int i=0;i<numOfBlocks;i++){

            int index= byteoffset[i];
            cIndexFile.seekg(index+6,ios::beg);
           getline(cIndexFile,h,'/');
           //h=cIndexFile.get();
            stringstream geek(h);
            int x=0;
            geek>>x;
            if(x>=iToken){
             while(r!=h){
            num++;
            index=index+5;
            cIndexFile.seekg(index,ios::cur);
            getline(cIndexFile,r,'/');
            h=cIndexFile.get();
  }

    }        }
    if(r==h) return num;
    else return -1;

}
int FirstEmptyBlock(fstream &cIndexFile){
return bigHeader.value;
}

};
int main() {
    fstream file;
    file.open("output.txt",ios::out|ios::in);
    sequenceSet s;
    s.CreateRecordFile(file,3,4);
    s.InsertVal(file,5,1);
    s.InsertVal(file,6,2);
    s.InsertVal(file,7,3);
    s.InsertVal(file,9,4);
   s.InsertVal(file,19,5);
    s.InsertVal(file,30,6);
   s.InsertVal(file,19,5);
   //s.DeleteKey(file,4);

    // s.print(file);
    file.close();
    return 0;
}
