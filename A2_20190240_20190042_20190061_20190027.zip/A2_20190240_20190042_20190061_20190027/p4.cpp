#include <iostream>
#include <bits/stdc++.h>

using namespace std;

struct Activity
{
    int starting,ending;
};


bool sorting (Activity s1, Activity s2)
{
    return (s1.ending< s2.ending);
}

void max_activity_num( Activity act[],int n)
{
    sort(act,act+n,sorting);
    cout<<"maximum number of activities that can be performed"<<endl;
    cout<<"{"<< act[0].starting<<" "<<act[0].ending<< "}"<<endl;
    int current=0;
    for (int i=1;i<n;i++)
    {
        if (act[i].starting>=act[current].ending)
        {
             cout<<"{"<< act[i].starting<<" "<<act[i].ending<< "}"<<endl;
            current=i;
        }
    }
}

int main()
{
    cout << "enter number of activities" << endl;
    int act_num;
    cin>> act_num;
    Activity activities[act_num];
     for (int i=0;i<act_num;i++)
    {
        cout<<"enter the starting and ending time of the activity"<<endl;
       cin>> activities[i].starting>>activities[i].ending;
    }

    max_activity_num(activities,act_num);

    return 0;

}
