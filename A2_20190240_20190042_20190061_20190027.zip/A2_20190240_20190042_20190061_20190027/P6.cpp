#include <iostream>
#include <vector>
#include <queue>
#include <cstdio>
using namespace std;
 struct v_e{
 pair<int,int> edge;
 int desti;
 };
int main(){
    int testCases,devices,edges,source,destination,result1=0,result2=0;
    cin>>testCases;
    int * results=new int(testCases);
    for(int i=0;i<testCases;i++){
            result1=0,result2=0;
        cin>>devices>>edges>>source>>destination;
          v_e server[edges];
         for(int j=0;j<edges;j++){
            cin>>server[j].edge.first>>server[j].edge.second>>server[j].desti;
         }
        for(int j=0;j<edges;j++){

            if(source==server[j].edge.first||source==server[j].edge.second){
            if(destination==server[j].edge.first||destination==server[j].edge.second){
                result1=result1+server[j].desti;
            }
            else if(destination!=server[j].edge.first||destination!=server[j].edge.second){
                result2=result2+server[j].desti;
            }

            }
            else if(destination!=server[j].edge.first||destination!=server[j].edge.second){
                result2=result2+server[j].desti;
            }
          }



        if(result1>result2 && result2!=0) results[i]=result2;
        else results[i]=result1;

    }
    for(int i=0;i<testCases;i++){
        if(results[i]==0) cout<<"Case #"<<i+1<<": unreachable"<<endl;
        else{
            cout<<"Case #"<<i+1<<": "<<results[i]<<endl;
        }
    }


return (0);
}
