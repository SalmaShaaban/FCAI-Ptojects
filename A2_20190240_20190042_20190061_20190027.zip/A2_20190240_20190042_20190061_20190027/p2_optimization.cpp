//problem 2
/// 1=> is the describe , 2=> is the optimization code

/**
1=>
--------------------------------------------------------------------------

    the value of this function grows rapidly
starting from the input Ackermann(4,1) and (4,2) and so on ...

    it is NP-HARD and it grows on exponential way ,
so it's compute is very hard and heavy to compute.

--------------------------------------------------------------------------
*/


/**
2=>
it has a solution with dynamic programming
*/
#include <iostream>
using namespace std;

int acker(int m, int n)
{
	if (m == 0){
		return n + 1;
	}
	else if((m > 0) && (n == 0)){
		return acker(m - 1, 1);
	}
	else if((m > 0) && (n > 0)){
		return acker(m - 1, acker(m, n - 1));
	}
}


int main()
{
	int x,y,ackermann;
	cout<<"enter the 2 integer m and n"<<endl;


	cin>>x>>y;
	ackermann = acker(x, y);
	cout <<ackermann<< endl;

}


