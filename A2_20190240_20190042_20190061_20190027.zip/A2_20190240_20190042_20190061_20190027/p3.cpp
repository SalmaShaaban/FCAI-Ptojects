#include <vector>
#include <cstdlib> /to use qsort/
#include <iostream>
using namespace std;


struct part
{
    int firNode;
    int wei;
};

struct line {
	int from, to, weight;
};

int lineCompare(const void* x, const void* y)
{
    struct line* n= (struct line*)x;
    struct line* m = (struct line*)y;
    return n->weight > m->weight;
}

int searchInSubgraphs(struct part subsets[], int i)
{
    if (subsets[i].firNode != i) {
        subsets[i].firNode = searchInSubgraphs(subsets, subsets[i].firNode);
    }
    return subsets[i].firNode;
}
void gatherSubgraphs(struct part subsets[], int x, int y)
{
    int root1 = searchInSubgraphs(subsets, x);
    int root2 = searchInSubgraphs(subsets, y);

    if (subsets[root1].wei < subsets[root2].wei) {
        subsets[root1].firNode= root2;
    } else if (subsets[root1].wei > subsets[root2].wei){
        subsets[root2].firNode = root1;
    } else {
        subsets[root2].firNode = root1;
     subsets[root1].wei = subsets[root1].wei+1;
    }
}

int main() {
	int numOfNodes, numOfLines;
	cin>>numOfNodes>>numOfLines;

	struct line* edge = (struct line*) malloc( numOfLines* sizeof( struct line ) );

for (int i = 0; i < numOfLines; ++i)
	{
		int str, end, w;
		cin>>str>>end>>w;
		edge[i].from = str;
		edge[i].to = end;
		edge[i].weight= w;
	}

	qsort(edge, numOfLines, sizeof(edge[0]), lineCompare);

	struct line subGraph[numOfNodes-1];
	int graphSize = 0;

	struct part subsets = (struct part) malloc( numOfNodes * sizeof(struct part) );
    for (int k = 0; k < numOfNodes; k++) {
        subsets[k].firNode= k;
        subsets[k].wei= 0;
    }
    //
    for(int j= 0; j< numOfLines; j++) {

    	struct line minEdge = edge[j];

    	int x = searchInSubgraphs(subsets, minEdge.from-1);
    	int y = searchInSubgraphs(subsets, minEdge.to-1);
    	if (x != y) {
    	    subGraph[graphSize++] = minEdge;
    	    gatherSubgraphs(subsets, x, y);
    	}
    	if(graphSize == numOfNodes-1) {
    		break;
    	}
    }

    int finalPath= 0;
    for(int i = 0; i < numOfNodes-1; i++) {
    	finalPath += subGraph[i].weight;
    }
    cout<<finalPath<<endl;
    return 0;
}
