/// problem_8
#include<iostream>
#include<algorithm>
using namespace std;

struct Job
{
    char id;
    int deadline;
    int profit;
};
//sort all jobs according the profit
bool jobCompar(Job a, Job b)
{
	 return (a.profit > b.profit);
}

// Returns minimum number of platforms required
void printJobScheduling(Job arr[], int n)
{
    // from STL Programming
	//  sort according the profit
	sort(arr, arr+n, jobCompar);

	int result[n]; //Sequence of jobs in the result
	bool slot[n]; //track free number of slots

	// make it free by initializing it by 0(false)
	for (int i=0; i<n; i++)
		slot[i] = false;

	//loop on given jobs
	for (int i=0; i<n; i++)
	{
        // starting from the last possible slot Find free slot
        for (int j=min(n, arr[i].deadline)-1; j>=0; j--)
        {

            if (slot[j]==false)
            {
               // while Free slot Add this job to result
                result[j] = i;
                // occupied slot   يعني اتاخدت و اطلع من اللوب
                slot[j] = true;
                break;
            }
        }
    }


	for (int i=0; i<n; i++)
	if (slot[i])
		cout << arr[result[i]].id << "  ";

}

int main()
{
    /**/
    ///first test case
	Job arr[] = { {'a', 4, 20}, {'b', 1, 10}, {'c', 1, 40},
				{'d', 1, 30}};
    ///second test case

    /*
Job arr[] ={ {'a', 2, 100}, {'b', 1, 19}, {'c', 2, 27},
             {'d', 1, 25},{'e', 3, 15}};
*/
	//array size
	int n = sizeof(arr)/sizeof(arr[0]);
	cout << "The maximum profit is -->  ";
	printJobScheduling(arr, n);

}
