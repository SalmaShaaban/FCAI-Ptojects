package hufman;

import java.util.PriorityQueue;
import java.util.Comparator;

/// همشي على كل بينري تري في كل نود وفرع
// هدخله على النودز 

class hNode {
  int Element;
  char Symbole;
  hNode left;
  hNode right;
}

// عشان نقارن النودز ببعضها
class ImplementComparator implements Comparator<hNode> {
  public int compare(hNode x, hNode y) {
    return x.Element - y.Element;
  }
}


public class Hufman {
    
    // بتاخد الهوفمان نود 
    // وبتاخد الروت بتاعة النود
    //والاسترينج كمان
    
  public static void printCode(hNode nRoot, String s) {
    
      // بنقارن بقا النودز ببعض
      
    if (nRoot.left == null && nRoot.right == null && Character.isLetter(nRoot.Symbole)) {

      System.out.println(nRoot.Symbole + "   |  " + s);

      return;
    }
    printCode(nRoot.left, s + "0");
    printCode(nRoot.right, s + "1");
  }

  public static void main(String[] args) {

    int n = 4;
    char[] charArray = { 'A', 'B', 'C', 'D' };
    int[] charfreq = { 5, 1, 6, 3 };

    PriorityQueue<hNode> q = new PriorityQueue<hNode>(n, new ImplementComparator());

    for (int i = 0; i < n; i++) {
      hNode hn = new hNode();

      hn.Symbole = charArray[i];
      // احتمالات الحروف
      hn.Element = charfreq[i];

      hn.left = null;
      hn.right = null;

      q.add(hn);
    }
// بتشيك على النودز
    hNode root = null;
//هتشيك على السيز علشان انتقل للنود جديدة
    while (q.size() > 1) {

      hNode x = q.peek();
      q.poll();

      hNode y = q.peek();
      q.poll();

      hNode f = new hNode();

      f.Element = x.Element + y.Element;
      f.Symbole = '-';
      f.left = x;
      f.right = y;
      root = f;

      q.add(f);
    }
    System.out.println(" TABEL OF Char | Huffman code ");
    System.out.println("--------------------");
    printCode(root, ""); 
    System.out.println(" the length is|");
    
    // 5,1,6, 3
    System.out.println("              |"+ "A =    " +1*5);
    System.out.println("              |"+ "B =    " + 3*1);
    System.out.println("              |"+ "C =    " +3*6);
    System.out.println("              |"+ "D =    "+2*3);
    System.out.println("----TOTAL------|"+ " =    34 ");
    
    

    
  }
}
