#include <iostream>
#include <vector>
#include <cmath>
using namespace std;
int FindMaximumTheives(int n, int k, char a[]){
vector<int> theif;
vector<int> polic;
int t=0,p=0,result;
for(int i=0; i<n;i++){
    if(a[i]=='T'){
        theif.push_back(i);
    }
    else if(a[i]=='P'){
        polic.push_back(i);
    }
}
while(t<theif.size()&& p<polic.size()){
    if(abs(theif[t]-polic[p])<=k){
       result++;
       t++;
       p++;
    }
    else if(theif[t]<polic[p]){
        t++;
    }
    else {p++;}
}
return(result);
}
int main()
{

    int n,k;
    cout<<"Enter the number of the array \n";
    cin>>n;
    char* arr=new char(n);
    cout<<"Enter the elements \n";
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    cout<<"Enter the k unit \n";
    cin>>k;
    cout<<"the maximum number of thieves that can be caught by the police = "<<FindMaximumTheives(n,k,arr)<<endl;
    return 0;
}
